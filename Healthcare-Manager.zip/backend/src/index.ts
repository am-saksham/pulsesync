import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { PrismaClient } from '@prisma/client';

dotenv.config();

const app = express();
const prisma = new PrismaClient();
const port = process.env.PORT || 3001;

app.use(cors());
app.use(express.json());

import authRoutes from './routes/auth.routes';
import userRoutes from './routes/user.routes';
import appointmentRoutes from './routes/appointment.routes';

// Basic health check route
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', message: 'Healthcare Manager API is running' });
});

// Attach Routes
app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/appointments', appointmentRoutes);

app.listen(port, () => {
  console.log(`Backend server is running on http://localhost:${port}`);
});
