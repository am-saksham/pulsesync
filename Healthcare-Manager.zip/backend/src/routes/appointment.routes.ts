import { Router } from 'express';
import { PrismaClient } from '@prisma/client';
import { authenticate, requireRole, AuthRequest } from '../middleware/auth';
import Redis from 'ioredis';

const router = Router();
const prisma = new PrismaClient();
const redis = new Redis(process.env.REDIS_HOST ? { host: process.env.REDIS_HOST, port: Number(process.env.REDIS_PORT) } : 'redis://localhost:6379');

// Helper to check slots
router.get('/available-slots', async (req, res) => {
  try {
    const { doctorId, date } = req.query; // date: YYYY-MM-DD
    if (!doctorId || !date) {
      return res.status(400).json({ error: 'doctorId and date are required' });
    }

    const doctor = await prisma.user.findUnique({
      where: { id: String(doctorId), role: 'DOCTOR' },
      include: {
        leaves: {
          where: {
            date: new Date(String(date))
          }
        }
      }
    });

    if (!doctor) return res.status(404).json({ error: 'Doctor not found' });
    
    // Check if doctor is on leave
    if (doctor.leaves.length > 0) {
      return res.json({ slots: [] }); // No slots available if on leave
    }

    const workingHours = doctor.workingHours as { start: string, end: string };
    const slotDuration = doctor.slotDuration || 30;

    // Fetch existing scheduled appointments
    const startOfDay = new Date(String(date));
    startOfDay.setUTCHours(0,0,0,0);
    const endOfDay = new Date(String(date));
    endOfDay.setUTCHours(23,59,59,999);

    const appointments = await prisma.appointment.findMany({
      where: {
        doctorId: String(doctorId),
        startTime: { gte: startOfDay, lte: endOfDay },
        status: 'SCHEDULED'
      }
    });

    const bookedTimes = appointments.map(a => a.startTime.getTime());

    // Generate slots
    const slots = [];
    const [startHour, startMin] = workingHours.start.split(':').map(Number);
    const [endHour, endMin] = workingHours.end.split(':').map(Number);
    
    let currentSlot = new Date(startOfDay);
    currentSlot.setUTCHours(startHour, startMin, 0, 0);

    const endTime = new Date(startOfDay);
    endTime.setUTCHours(endHour, endMin, 0, 0);

    while (currentSlot < endTime) {
      if (!bookedTimes.includes(currentSlot.getTime())) {
        slots.push(new Date(currentSlot));
      }
      currentSlot = new Date(currentSlot.getTime() + slotDuration * 60000);
    }

    res.json({ slots });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Book appointment
router.post('/book', authenticate, requireRole(['PATIENT']), async (req: AuthRequest, res) => {
  try {
    const { doctorId, startTime, symptoms } = req.body;
    const patientId = req.user!.id;
    
    const start = new Date(startTime);
    const lockKey = `lock:appointment:${doctorId}:${start.getTime()}`;

    // 1. Pessimistic Lock in Redis (holds for 10 seconds)
    const acquiredLock = await redis.setnx(lockKey, "LOCKED");
    if (!acquiredLock) {
      return res.status(409).json({ error: 'Slot is currently being booked by someone else. Try again in a few seconds.' });
    }
    await redis.expire(lockKey, 10);

    // 2. Validate doctor and duration
    const doctor = await prisma.user.findUnique({ where: { id: doctorId } });
    if (!doctor || doctor.role !== 'DOCTOR') {
      await redis.del(lockKey);
      return res.status(404).json({ error: 'Doctor not found' });
    }

    const endTime = new Date(start.getTime() + (doctor.slotDuration || 30) * 60000);

    // 3. Database operation (relies on compound unique index [doctorId, startTime])
    const appointment = await prisma.appointment.create({
      data: {
        patientId,
        doctorId,
        startTime: start,
        endTime,
        symptoms
      }
    });

    await redis.del(lockKey);

    // TODO: Enqueue BullMQ job for LLM pre-visit summary, Email, and Google Calendar creation

    res.status(201).json({ message: 'Appointment booked successfully', appointment });
  } catch (error: any) {
    console.error(error);
    // Prisma unique constraint violation
    if (error.code === 'P2002') {
      return res.status(409).json({ error: 'Slot is already booked' });
    }
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Post-visit notes
router.post('/:id/post-visit', authenticate, requireRole(['DOCTOR']), async (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    const { doctorNotes, prescription } = req.body;

    const appointment = await prisma.appointment.findUnique({ where: { id } });
    if (!appointment || appointment.doctorId !== req.user!.id) {
      return res.status(404).json({ error: 'Appointment not found' });
    }

    const updated = await prisma.appointment.update({
      where: { id },
      data: {
        doctorNotes,
        prescription,
        status: 'COMPLETED'
      }
    });

    // TODO: Enqueue BullMQ job for LLM post-visit summary generation & email

    res.json({ message: 'Visit completed', appointment: updated });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

export default router;
